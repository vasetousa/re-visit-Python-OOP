from project.people.child import Child
from project.rooms.alone_old import AloneOld
from project.rooms.alone_young import AloneYoung
from project.rooms.room import Room
from project.rooms.young_couple import YoungCouple
from project.rooms.young_couple_with_children import YoungCoupleWithChildren


class Everland:
    def __init__(self):
        self.rooms = []

    def add_room(self, room: Room):
        self.rooms.append(room)

    def get_monthly_consumptions(self):
        total_consumption = 0

        return f"Monthly consumption: {total_consumption}$."

    def pay(self):
        for rooms in self.rooms:
            calculation = Room.calculate_expenses(rooms, rooms.kids, rooms.appliances)
            if rooms.budget >= calculation:
                rooms.budget -= calculation
                print(f"{rooms.family_name} paid {calculation}$ and have {rooms.budget}$ left.")
            else:
                self.rooms.remove(rooms)
                print(f'{rooms.family_name} does not have enough budget and must leave the hotel.')

    def status(self):
        pass

#
# hotel = Everland()
#
# child1 = Child(5, 1, 2, 1)
# child2 = Child(3, 2)
#
# aloneOld = AloneOld('Vasilev', 1000, 2000)
# young_couple_with_children = YoungCoupleWithChildren("Peterson", 600, 520, child1, child2)
# young_couple = YoungCouple("Johnsons", 150, 205)
# # print(young_couple_with_children.calculate_expenses([1, 2, 3, 4]))
# # print(young_couple.calculate_expenses([5, 5, 5, 5]))
#
#
# hotel.add_room(young_couple_with_children)
# hotel.add_room(young_couple)
#
# print(hotel.get_monthly_consumptions())
# print(hotel.pay())
#
# print()