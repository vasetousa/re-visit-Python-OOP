class Room:
    MONTHLY_EXPENSES = 30
    def __init__(self, family_name: str, budget: float):
        self.family_name = family_name
        self.budget = budget
        self.members_count = 0
        self.children = []
        self.expenses = 0

    @property
    def expenses(self):
        return self.__expenses

    @expenses.setter
    def expenses(self, value):
        if value < 0:
            raise ValueError('Expenses cannot be negative')
        self.__expenses = value

    def calculate_expenses(self, *data):
        result = 0
        count_elements = len(data)
        for el in range(count_elements):
            for el2 in data[el]:
                result += el2.cost

        return result   # children + appliances