from project.appliances.fridge import Fridge
from project.appliances.stove import Stove
from project.appliances.tv import TV
from project.rooms.room import Room


class YoungCouple(Room):
    ROOM_COST = 20

    def __init__(self, family_name: str, salary_one, salary_two):
        super().__init__(family_name, salary_one + salary_two)
        self.budget = salary_one + salary_two
        self.room_cost = YoungCouple.ROOM_COST
        self.members_count = 2
        self.appliances = [TV(), Fridge(), Stove()]
        # TODO calculate expenses
        #  for each person
