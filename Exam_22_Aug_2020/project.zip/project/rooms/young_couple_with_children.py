from project.appliances.appliance import Appliance
from project.appliances.fridge import Fridge
from project.appliances.laptop import Laptop
from project.appliances.tv import TV
from project.people.child import Child
from project.rooms.room import Room


class YoungCoupleWithChildren(Room):
    ROOM_COST = 30

    def __init__(self, family_name, salary_one, salary_two, *children):
        super().__init__(family_name, salary_two + salary_two)
        self.cost = YoungCoupleWithChildren.ROOM_COST
        self.members_count = 2 + len(children)
        self.children = list(children)
        self.appliances = [TV(), Fridge(), Laptop()]  # TV, fridge, laptop for each person. calc expenses and child expenses
        """ children, appliances, room """
        self.app_cost_for_all_guests = len(self.appliances) * self.members_count
        self.calculate_expenses(self.children, self.appliances)
#
#
#
# child1 = Child(5, 1, 2, 1)
# child2 = Child(3, 2)
#
#
# yc = YoungCoupleWithChildren("dadsad", 1000, 2000, child1, child2)
