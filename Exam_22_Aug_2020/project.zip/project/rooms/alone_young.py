from project.appliances.tv import TV
from project.rooms.room import Room


class AloneYoung(Room):
    ROOM_COST = 10
    def __init__(self, family_name: str, salary: float):
        super().__init__(family_name, salary)
        self.cost = AloneYoung.ROOM_COST
        self.members_count = 1
        self.appliances = [TV()]
        # TODO calculate expenses of appliances



# ay = AloneYoung("vasilev", 1000)
# print(ay.members_count)